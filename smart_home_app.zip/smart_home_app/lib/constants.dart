import 'package:flutter/material.dart';


Color textColor = const Color(0xFF42347F);
Color primaryColor = const Color(0xFF7E59F8);



